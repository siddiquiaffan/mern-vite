"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
const express_1 = __importDefault(require("express"));
const path_1 = __importDefault(require("path"));
const cors_1 = __importDefault(require("cors"));
const fs_1 = require("fs");
const dotenv_1 = __importDefault(require("dotenv"));
dotenv_1.default.config();
const app = (0, express_1.default)();
app.use(express_1.default.json());
// allow cors
app.use((0, cors_1.default)({
    origin: process.env.NODE_ENV === "production" ? process.env.ORIGIN : "http://localhost:5173",
    // origin: '*',
}));
app.use(express_1.default.static(path_1.default.join(__dirname, "./dist")));
// read all routes fom routes folder and use them in app. Base url is /api
const routes = (0, fs_1.readdirSync)(path_1.default.join(__dirname, "./routes")).map((file) => require(`./routes/${file}`).default);
routes.forEach((route) => {
    app.use("/api", route);
});
app.get("*", (req, res) => {
    res.sendFile(path_1.default.join(__dirname, "./dist", 'index.html'));
});
app.listen(8000, () => console.log("Server running on port 8000"));
// 4dee2cbba3bb e1f2fb7ddd4b
